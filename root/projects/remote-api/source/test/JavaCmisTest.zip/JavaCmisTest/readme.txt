This simple example connects to the Alfresco CMIS Server and displays the names
of the folders within the Alfresco root folder called "Company Home".

The example utilizes the Alfresco CMIS Web Services interfaces.

The example is stand-alone and includes all of its dependencies.

Steps to execute the example...

Note: the batch script requires Windows, but can be easily ported to other
      operating systems.

1) Unpack JavaCmisTest.zip
2) Start Alfresco Server
3) Run cmis-test.bat http://<alfresco_host>:<alfresco_port> <username> <password>

Upon successful completion, a list of folder names is presented.

The source code for the example is also included.